class MessageParser {
  constructor(actionProvider, state) {
    this.actionProvider = actionProvider;
    this.state = state;
  }

  parse(message) {
    const lowerCaseMessage = message.toLowerCase()
    
    if (lowerCaseMessage.includes("hello")) {
      this.actionProvider.greet('Hi, Friend!')
    }
    if (lowerCaseMessage.includes("how are you")) {
      this.actionProvider.greet('I am doing good. How are you?')
    }
    if (lowerCaseMessage.includes("thank")) {
      this.actionProvider.greet('You are very welcome!')
    }


  }
}

export default MessageParser;
